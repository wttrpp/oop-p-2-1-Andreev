﻿using ConsoleApp1.NewFolder1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address(26852, "Россия", "Тула", "Донской", 13, 15);
            address.printAdress();
            Console.ReadLine();
            

        }
    }
}
