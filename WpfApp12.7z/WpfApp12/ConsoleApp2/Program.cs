﻿using ConsoleApp2.NewFolder1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Program
    {
        static void Main(string[] args)
        {
            var myRectangle = new Rectangle(13, 69);
            Console.WriteLine($"Area: {myRectangle.Area}");
            Console.WriteLine($"Perimeter: {myRectangle.Perimeter}");
            Console.ReadLine();
        }
    }
}
